import zipfile
import re
import csv
import urllib.request
from pathlib import Path
from collections import defaultdict

FILE_ID = "1vlczaocHyghEW5Q-6WprqB2nnna_wrLE"
ZIP_PATH = Path("stackoverflow_data.zip")
DATA_DIR = Path("stackoverflow_data")
KEYWORDS = ["python", "java", "javascript", "sql", "rust"]


def download_google_drive_file(file_id, output_path):
    url = f"https://drive.google.com/uc?id={file_id}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    resp = urllib.request.urlopen(req)
    content = resp.read().decode("utf-8", errors="replace")

    action_match = re.search(r'action="([^"]+)"', content)
    uuid_match = re.search(r'name="uuid"[^>]*value="([^"]+)"', content)
    action = action_match.group(1) if action_match else f"https://drive.google.com/uc?export=download&id={file_id}"
    uuid = uuid_match.group(1) if uuid_match else ""

    dl_url = f"{action}?id={file_id}&confirm=t&uuid={uuid}"
    req2 = urllib.request.Request(dl_url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req2) as response:
        with open(output_path, "wb") as f:
            f.write(response.read())


def ensure_data():
    if not ZIP_PATH.exists():
        download_google_drive_file(FILE_ID, ZIP_PATH)
    if not DATA_DIR.exists():
        with zipfile.ZipFile(ZIP_PATH, "r") as zf:
            zf.extractall(DATA_DIR)


def count_keywords():
    csv_files = sorted(DATA_DIR.rglob("*.csv"))
    counts = defaultdict(int)
    total_rows = 0

    for csv_file in csv_files:
        with open(csv_file, newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            for row in reader:
                total_rows += 1
                text = " ".join(row).lower()
                for kw in KEYWORDS:
                    if kw in text:
                        counts[kw] += 1

    return len(csv_files), total_rows, counts


def main():
    ensure_data()
    num_files, total_rows, counts = count_keywords()
    print(f"Number of CSV files: {num_files}")
    print(f"Total number of rows: {total_rows}")
    for kw in KEYWORDS:
        print(f"Rows containing {kw}: {counts[kw]}")
    most_common = max(KEYWORDS, key=lambda kw: counts[kw])
    print(f"Most common keyword: {most_common}")


if __name__ == "__main__":
    main()
